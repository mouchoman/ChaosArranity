if(typeof(require) !== "undefined"){
	require("funclib");
    require("adamantite-repair-turret")
}